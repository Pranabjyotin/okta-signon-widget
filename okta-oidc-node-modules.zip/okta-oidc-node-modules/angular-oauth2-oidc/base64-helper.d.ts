export declare function b64DecodeUnicode(str: any): string;
