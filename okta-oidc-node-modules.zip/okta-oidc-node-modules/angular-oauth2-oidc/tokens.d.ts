import { InjectionToken } from '@angular/core';
import { AuthConfig } from './auth.config';
export declare const AUTH_CONFIG: InjectionToken<AuthConfig>;
