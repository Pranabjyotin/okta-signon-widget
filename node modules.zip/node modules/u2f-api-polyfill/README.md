# U2F API

This is a JavaScript polyfill, implementing the high-level U2F JavaScript API
for Chrome.

Google wrote and owns this code. It's just a pain to manually pull it from their
[u2f-ref-code](https://github.com/google/u2f-ref-code) repo, so I made a NPM
package.
