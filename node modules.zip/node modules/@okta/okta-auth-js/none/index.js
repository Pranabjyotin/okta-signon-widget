module.exports = require('../lib/clientBuilder')();
