var jqueryRequest = require('./jqueryRequest');
module.exports = require('../lib/clientBuilder')(jqueryRequest);
